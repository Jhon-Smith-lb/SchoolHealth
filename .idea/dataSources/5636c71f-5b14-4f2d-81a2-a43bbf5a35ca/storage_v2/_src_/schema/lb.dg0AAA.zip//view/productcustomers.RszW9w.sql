create definer = root@localhost view productcustomers as
select `lb`.`customers`.`cust_name`    AS `cust_name`,
       `lb`.`customers`.`cust_contact` AS `cust_contact`,
       `lb`.`orderitems`.`prod_id`     AS `prod_id`
from `lb`.`customers`
       join `lb`.`orders`
       join `lb`.`orderitems`
where ((`lb`.`customers`.`cust_id` = `lb`.`orders`.`cust_id`) and
       (`lb`.`orderitems`.`order_num` = `lb`.`orders`.`order_num`));

